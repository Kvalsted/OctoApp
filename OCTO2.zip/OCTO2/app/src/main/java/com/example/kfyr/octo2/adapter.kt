package com.example.kfyr.octo2

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

class MainAdapter: RecyclerView.Adapter<CustomViewHolder>()
{
    override fun onBindViewHolder(holder: CustomViewHolder?, position: Int) {

    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): CustomViewHolder {


        val layoutInflater = LayoutInflater.from(parent?.context)
        var cellForRow = layoutInflater.inflate(R.layout.file_row, parent, false)
        return CustomViewHolder(cellForRow)


    }

    override fun getItemCount(): Int {
        return 50
    }
}

class CustomViewHolder(v: View) : RecyclerView.ViewHolder(v)
{}
package com.example.kfyr.octo2

import android.content.Context
import android.util.Log
//import com.example.kfyr.octo2.MainActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import java.security.AccessController.getContext

class HttpRequestHandler(var context: Context)
{
    fun httpGet()
    {
        val url = "https://api.myjson.com/bins/kp9wz"
        val mQueue = Volley.newRequestQueue(context);

        val request = JsonObjectRequest(Request.Method.GET, url, null,
                Response.Listener { response ->
                    try {
                        val jsonArray = response.getJSONArray("employees")

                        for (i in 0 until jsonArray.length()) {
                            val employee = jsonArray.getJSONObject(i)

                            Log.d("JSON: ", employee.toString())
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }, Response.ErrorListener { error -> error.printStackTrace() })

        mQueue.add(request)
    }
}